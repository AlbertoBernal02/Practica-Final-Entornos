package ejercicio;
import java.util.*;

public class BatallaDigital {
    private Digimon enemigo;

    public BatallaDigital() {
        Random rand = new Random();
        int digimonEnemigo = rand.nextInt(3);
        switch (digimonEnemigo) {
            case 0 -> enemigo = new Digimon("Agumon");
            case 1 -> enemigo = new Digimon("Gabumon");
            case 2 -> enemigo = new Digimon("Patamon");
        }
    }

    public void elige(Domador domador) {
        Scanner scanner = new Scanner(System.in);
        Digimon elegido = null;

        while (elegido == null) {
            System.out.println("Elija el Digimon que quiere usar:");
            for (int i = 0; i < domador.getEquipo().size(); i++) {
                Digimon digimon = domador.getEquipo().get(i);
                if (!digimon.isMuerto()) {
                    System.out.println((i + 1) + ". " + digimon.getNombre());
                }
            }
            int opcion = scanner.nextInt() - 1;
            if (opcion >= 0 && opcion < domador.getEquipo().size() && !domador.getEquipo().get(opcion).isMuerto()) {
                elegido = domador.getEquipo().get(opcion);
            } else {
                System.out.println("Opción no válida o el Digimon está muerto. Elija otro.");
            }
        }
        pelea(domador, elegido);
    }

    public void pelea(Domador domador, Digimon digimon) {
        Scanner scanner = new Scanner(System.in);
        while (enemigo.getSalud() > 0 && digimon.getSalud() > 0) {
            System.out.println("Elija su acción:");
            System.out.println("1. Ataque1");
            System.out.println("2. Ataque2");
            System.out.println("3. Capturar");
            int accion = scanner.nextInt();

            switch (accion) {
                case 1 -> digimon.usarAtaque1(enemigo);
                case 2 -> digimon.usarAtaque2(enemigo);
                case 3 -> {
                    domador.capturar(enemigo);
                    return;
                }
                default -> System.out.println("Opción no válida.");
            }

            if (enemigo.getSalud() > 0) {
                enemigo.usarAtaque1(digimon);
                System.out.println("El enemigo ataca con Ataque1.");
            }

            System.out.println("Salud del enemigo: " + enemigo.getSalud());
            System.out.println("Salud de tu Digimon: " + digimon.getSalud());

            if (digimon.getSalud() <= 0) {
                System.out.println(digimon.getNombre() + " ha muerto y no puede ser usado nuevamente.");
            }
        }

        if (enemigo.getSalud() <= 0) {
            System.out.println("¡Has derrotado al enemigo!");
        }
    }
}