package ejercicio;
import java.util.*;

public class Digimon {
    private String nombre;
    private int nivel;
    private int ataque;
    private int salud;
    private int dp1;
    private int dp2;
    private boolean muerto;

    public Digimon(String nombre) {
        this.nombre = nombre;
        Random rand = new Random();
        this.nivel = rand.nextInt(5) + 1; // Nivel entre 1 y 5
        this.ataque = 5 * nivel;
        this.salud = 10 * nivel;
        this.dp1 = 10;
        this.dp2 = 10;
        this.muerto = false;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNivel() {
        return nivel;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getSalud() {
        return salud;
    }

    public int getDp1() {
        return dp1;
    }

    public int getDp2() {
        return dp2;
    }

    public boolean isMuerto() {
        return muerto;
    }

    public void setSalud(int salud) {
        this.salud = salud;
        if (this.salud <= 0) {
            this.muerto = true;
            this.salud = 0;
        }
    }

    public void usarAtaque1(Digimon enemigo) {
        if (dp1 > 0) {
            enemigo.setSalud(enemigo.getSalud() - ataque);
            dp1--;
        } else {
            System.out.println(nombre + " no tiene suficientes DP para Ataque1");
        }
    }

    public void usarAtaque2(Digimon enemigo) {
        if (dp2 > 1) {
            enemigo.setSalud(enemigo.getSalud() - 2 * ataque);
            dp2 -= 2;
        } else {
            System.out.println(nombre + " no tiene suficientes DP para Ataque2");
        }
    }
}

